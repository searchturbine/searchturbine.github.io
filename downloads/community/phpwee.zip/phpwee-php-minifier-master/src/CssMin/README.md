#PHPWee

Open-source (BSD) PHP inline minifier functions for HTML, XHTML, HTML5, CSS 1-3 and Javascript. http://searchturbine.com/php/phpwee

This folder contains the CSSMin class Copyright (c) 2011 Joe Scylla <joe.scylla@gmail.com>.  It has beenmodified for the PHPWee namespace. 
