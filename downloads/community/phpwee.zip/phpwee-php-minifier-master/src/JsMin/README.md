#PHPWee

Open-source (BSD) PHP inline minifier functions for HTML, XHTML, HTML5, CSS 1-3 and Javascript. http://searchturbine.com/php/phpwee

This folder contains the JsMin class Copyright (c) 2002 Douglas Crockford  (www.crockford.com). It has been modified for the PHPWee namespace. 
